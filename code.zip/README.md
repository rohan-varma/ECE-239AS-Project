### ECE-239AS-Project

#### Setup
- Download the data and place it in a directory called `project_datasets/`


### Running Code

- The code requires Python3 & Pytorch to run. Each file has command line arguments that can be used to run the code. 